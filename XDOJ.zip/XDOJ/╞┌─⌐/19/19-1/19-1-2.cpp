#include<stdio.h>
struct Stu{
	int age;
	int id;
	int grades;
};
int main()
{
	int n=0;
	int i=0;
	scanf("%d",&n);
	Stu info[100];
	for(i=0;i<n;i++)
	{
		scanf("%d%d%d",&info[i].age,
					   &info[i].id,
					   &info[i].grades);	
	}
	int g_max=0;
	for(i=0;i<=n-1;i++)
	{
		if(info[g_max].grades<info[i].grades)
		{
			g_max=i;
		}
		else if(info[g_max].grades==info[i].grades)
		{
			if(info[g_max].id<info[i].id)
			{
				g_max=i;
			}
		}
	}
	int a_min=0;
	for(i=0;i<=n-1;i++)
	{
		if(info[a_min].age>info[i].age)
		{
			a_min=i;
		}
		else if(info[a_min].grades==info[i].grades)
		{
			if(info[a_min].id>info[i].id)
			{
				a_min=i;
			}
		}
	}
	printf("%d %d %d\n",info[g_max].age,
					    info[g_max].id,
					    info[g_max].grades);
	printf("%d %d %d",info[a_min].age,
					  info[a_min].id,
					  info[a_min].grades);
	return 0;
}
