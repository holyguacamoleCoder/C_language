#include<stdio.h>
#include<string.h>
int main()
{
	int i,k,sum2,sum1,n=0,flag=0;
	char s[19];
	gets(s);
	for(i=0;i<strlen(s);i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			n=n*10+(s[i]-48);
			if(i==strlen(s)-1)
			sum2=n;
			else
			if((s[i+1]<'0')||(s[i+1]>'9'))
			{
				if(flag==0)
				{
					sum1=n;
					n=0;
					flag=1;	
				}
				else sum2=n;
			}
		}
		else continue;
	}
	for(i=0;i<strlen(s);i++)
	{
		if((s[i]<'0')||(s[i]>'9')&&s[i]!=32)
		{
			if(s[i]=='+') k=sum1+sum2;
			else if(s[i]=='-') k=sum1-sum2;
			else if(s[i]=='*') k=sum1*sum2;
			else if(s[i]=='/') k=sum1/sum2;
			else if(s[i]=='%') k=sum1%sum2;
		}
	}
	printf("%d",k);
	return 0;
 } 
