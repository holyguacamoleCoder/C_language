#include<stdio.h>
#include<ctype.h>
void count(char *str)
{
	int num[5]={0};
	while(*str)
	{
		if(isupper(*str))
		{
			num[0]++;
		}
		else if(islower(*str))
		{
			num[1]++;
		}
		else if(isspace(*str))
		{
			num[2]++;
		}
		else if(isdigit(*str))
		{
			num[3]++;
		}
		else 
		{
			num[4]++;
		}
		str++;
	}
	for(int i=0;i<5;i++)
	{
		printf("%d ",num[i]);
	}
}

int main()
{
	char str[100];
	gets(str);
	count(str);
	return 0;
}
