#include<stdio.h>
void date(int d2,int d)
{
//	if(d<=31)
//	{
//		printf("1 %d",d);
//	}
//	else if(d>31 && d<=31+d2)
//	{
//		printf("2 %d",d-31);
//	}
//	else if(d>31+d2 && d<=62+d2)
//	{
//		printf("3 %d",d-62);
//	}
//	else if(d>62+d2 && d<=92+d2)
//	{
//		printf("4 %d",d-92);
//	}
//	else if(d>92+d2 && d<=123+d2)
//	{
//		printf("5 %d",d-123);
//	}
//	else if(d>123+d2 && d<=153+d2)
//	{
//		printf("6 %d",d-153);
//	}
//	else if(d>62+d2 && d<=184+d2)
//	{
//		printf("7 %d",d-184);
//	}
//	else if(d>62+d2 && d<=215+d2)
//	{
//		printf("8 %d",d-215);
//	}
//	else if(d>62+d2 && d<=245+d2)
//	{
//		printf("9 %d",d-245);
//	}
//	else if(d>62+d2 && d<=92+d2)
//	{
//		printf("10 %d",d-92);
//	}
//	else if(d>62+d2 && d<=92+d2)
//	{
//		printf("11 %d",d-92);
//	}
//	else if(d>62+d2 && d<=92+d2)
//	{
//		printf("12 %d",d-92);
//	}
//		
	int i=0;
	int sum_date[12]={31,31+d2,62+d2,92+d2,123+d2,153+d2,184+d2,215+d2,245+d2,276+d2,306+d2,337+d2};
	if(d<=31)
	{
		printf("%d %d",1,d);
	}
	else 
	{
		for(i=1;i<12;i++)
			{
				if(d>=sum_date[i-1] && d<=sum_date[i]) 
				{
					printf("%d %d",i+1,d-sum_date[i-1]);
					break;
				}
			}
	}
}
int main()
{
	int y=0;
	int d=0;
	int day_2=28;
	scanf("%d %d",&y,&d);
	if((y%4==0 && y%100!=0) || y%400==0)//����
	{
		day_2=29;
		date(day_2,d);
	}
	else//ƽ��
	{
		date(day_2,d);
	}
	return 0;
}
