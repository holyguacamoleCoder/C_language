#include<stdio.h>
int main()
{
	int n=0;
	int i=0;
	int part=1;
	int arr[1000];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=1;i<n;i++)
	{
		if(arr[i]!=arr[i-1])
				{
					part++;
				}
	}
	printf("%d",part);
	return 0;
}
