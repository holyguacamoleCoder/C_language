#include<stdio.h>
void move(int *arr,int n)
{
	int i=0;
	while(n--)//����
	{
		*(arr+10+i)=arr[i];
		i++;
	}
}
int main()
{
	int p0=0;
	scanf("%d",&p0);
	int p=p0+1;
    int arr[20]={1,2,3,4,5,6,7,8,9,10};
    move(arr,p);
    for(int i=p;i<10+p;i++)//����ǰ��
    {
		printf("%d ",*(arr+i));
	}
    return 0;
}
