//T1 �ɹ���������
#include<stdio.h>
int main()
{
	int n;
	int i,j,k;
	scanf("%d",&n);
	int a[n]={0};
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int three[3];
	int tri=0;
	for(i=0;i<n-2;i++)
	{
		three[0]=a[i];
		three[1]=a[i+1];
		three[2]=a[i+2];
		for(j=0;j<3;j++)
		{
			for(k=0;k<2-j;k++)
			{
				if(three[k]<three[k+1])
				{
					int tmp=three[k+1];
					three[k+1]=three[k];
					three[k]=tmp;
				}
			}
		}
		if(three[2]+three[1]>three[0] && three[0]-three[2]<three[1])
		{
			tri++;
		}
	}
	printf("%d",tri);
	return 0;
}
