#include<stdio.h>
int main()
{
	int i=0;
	int count=0;
	for(i=100;i<500;i++)
	{
		if(i%7==0 || i%11==0 )
			if(i%7==0 && i%11==0);
			else
				count++;		
	}
	printf("%d",count);
	return 0;
}
