#include<stdio.h>
int main()
{
	int n=0;
	int i=0;
	int count=0; 
	int arr[100]={0};
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=1;i<n-1;i++)
	{
		if((arr[i]>arr[i-1] && arr[i]>arr[i+1]) || ((arr[i]<arr[i-1] && arr[i]<arr[i+1])))
		count++;
	}
	printf("%d",count);
	return 0;
}
