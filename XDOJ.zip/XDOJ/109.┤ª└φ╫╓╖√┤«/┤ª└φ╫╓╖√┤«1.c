#include<stdio.h>
#include<string.h>
 
void buble_sort(char less[])
{
	int i,j; 
	int len = strlen(less);
	char temp;
	for (i = 0; i < len; i++)
		for (j = 0; j < len - 1 - i;j++)
			if (less[j]>less[j + 1])
			{
				temp = less[j];
				less[j] = less[j + 1];
				less[j + 1] = temp;
			}
}
int main()
{
	char str[100] = { 0 }, more[100] = { 0 }, less[100] = { 0 };
	int len,j=0,k=0,i;
	char first;
	scanf("%s", str);
	len = strlen(str);
	first = str[0];
	for (i = 1; i < len; i++)
	{
		if (str[i] > first)
		{
			more[j] = str[i];
			j++;
		}
		if (str[i] <= first)
		{
			less[k] = str[i];
			k++;
		}
	}
	buble_sort(less);
	for (i = 0; i < j; i++)
		printf("%c", more[i]);
	printf("%c", first);
	for (i = 0; i < k; i++)
		printf("%c", less[i]);
	
	return 0;
}
