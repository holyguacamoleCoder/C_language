#include<stdio.h>
#include<string.h>
void fun(char*s,char*t)
{
	int i=0,j=0;
	for(i=0;i<(int)strlen(s);i++)
	{
		if(i%2==1)
		{
			i++;
		}
		t[j++]=s[i];
	}
	t[++j]='\0';
}

int main()
{
	char s[100],t[100];
	gets(s);
	fun(s,t);
	printf("%s",t);
	return 0;
}
