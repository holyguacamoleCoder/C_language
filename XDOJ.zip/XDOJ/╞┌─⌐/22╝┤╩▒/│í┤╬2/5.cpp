//�ӷ��ֽ�����
#include<stdio.h>
void output(int i,int n)
{
	int sum=0;
	while(sum!=n)
	{
		printf("%d ",i);
		sum+=i;
		i++;
	}
	printf("\n");
}
int main()
{
	int n=0;
	scanf("%d",&n);
	int i,j,sum=n,right,exist=0;
	for(j=n/2+n%2;j>0;j--)
	{
		sum=n;
		right=0;
		for(i=j;i>0;i--)
		{
			sum-=i;
			if(sum==0)
			{
				right=1;
				break;
			}
			else if(sum<0)
			{
				break;
			}
		}
		if(right==1)
		{
			output(i,n);
			exist++;
		}
	}
	if(exist==0)
	{
		printf("-1");
	}
	return 0;
}
