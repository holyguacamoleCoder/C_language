#include<stdio.h>
#include<string.h>
int main()
{
	int i=0;
	int g1=0,g2=0,g3=0,g4=0,g5=0,g6=0,g7=0;
	int kind=0;
	char password[50];
	gets(password);
	int len=strlen(password);
	if(len!=0)
	{
		g1=1;//�ǿ�+1
	}
	if(len>8)
	{
		g2=1;//��8λ+1
	}
	while(password[i]!='\0')//�ж�����
	{
		if(password[i]>='0' && password[i]<='9')
		{
			g3=1;
		}
		else if(password[i]>='A' && password[i]<='Z')
		{
			g4=1;
		}
		else if(password[i]>='a' && password[i]<='z')
		{
			g5=1;
		}
		else
		{
			g6=1;
		}
		i++;
	}
	kind=g3+g4+g5+g6;//�ж��ַ�����
	switch(kind)
	{
		case 2:g7=1;break;
		case 3:g7=2;break;
		case 4:g7=3;break;
	}
	printf("%d",g1+g2+g7);
	return 0;
}
