#include<stdio.h>
int main()
{
	int i=0,j=0;
	int arr[7][7];
	for(i=1;i<6;i++)
	{
		for(j=1;j<6;j++)
		{
			scanf("%d",&arr[i][j]);
		}
	}
	int min_vaule=arr[1][1];
	int min_r=1;
	int min_c=1;
	for(i=1;i<6;i++)
	{
		for(j=1;j<6;j++)
		{
			if(arr[i][j]<min_vaule)
			{
				min_vaule=arr[i][j];
				min_r=i;
				min_c=j;
			}
		}
	}
	printf("%d %d\n",min_r-1,min_c-1);
	printf("%d",arr[min_r+1][min_c]+arr[min_r-1][min_c]+
				arr[min_r][min_c+1]+arr[min_r][min_c-1]);
	return 0;
}
