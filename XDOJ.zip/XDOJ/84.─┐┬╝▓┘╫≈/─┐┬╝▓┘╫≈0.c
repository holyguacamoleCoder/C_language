#include<stdio.h>
#include<string.h>

int main()
{
	char a[200];
	gets(a);
	char b[200];
	while(1)
	{
		gets(b);		
		if(strcmp(b,"pwd")==0) break;
	
		else if(strcmp(b,"cd /")==0)
		{ //1
		   if(strcmp(a,"/")!=0)
		        strcpy(a,"/") ;
		}
		
		else if(strcmp(b,"cd ..")==0) 
		{//2
			if(strcmp(a,"/")!=0)
		    {    
		        int n=strlen(a);
			    int f;
			    for(f=n-1;f>=0;f--)
			    {
			   	    if(a[f]=='/')//����һ��Ŀ¼��λ�� 
			   	        break;
			    }
			    //����0�� f-1
			    char c[302];
			    if(f>0)//���Ǹ�Ŀ¼ 
			    {
			        int y=0;
			        for(;y<=f-1;y++)
			        c[y]=a[y];
			        c[y]='\0';
			        strcpy(a,c);
			    }
			    else if(f==0)//�Ǹ�Ŀ¼ 
			    {
			   	    strcpy(a,"/");
			    }
		    }
		}
		
		else if(strncmp(b,"cd ",3)==0&&strncmp(b,"cd /",4)!=0&&strcmp(b,"cd ..")!=0)
		{   //3 
		    int n1=strlen(b);
		    char d[234];
			d[0]='/';
			int u=3;
		    for(;u<n1;u++)
		    {
		    	d[u-3+1]=b[u];
		    }
		    d[u-2]='\0';
		    //������Ҫƴ�ӵ�Ŀ¼����d�ַ�����
		    if(strcmp(a,"/")==0)// ����Ǹ�Ŀ¼ 
			    strcpy(a,d);
			else//������Ǹ�Ŀ¼ 
			    strcat(a,d);
		}
		
		else if(strncmp(b,"cd /",4)==0&&strlen(b)>4)
		{
			int n2=strlen(b);
		    char d2[234];
			int u2=3;
		    for(;u2<n2;u2++)
		    {
		    	d2[u2-3]=b[u2];
		    }
		    d2[u2-3]='\0';
			strcpy(a,d2);
		}
		//printf("%s\n",a);
	}
	
	printf("%s",a);
	printf("\n");
	return 0;
}

