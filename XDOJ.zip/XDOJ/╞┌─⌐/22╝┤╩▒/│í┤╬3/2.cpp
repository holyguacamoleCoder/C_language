//T2 ROT3����
#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main()
{
	int i=0;
	char src[100];
	gets(src);
	int len=(int)strlen(src);
	for(i=0;i<len;i++)
	{
		if(isupper(src[i]))
		{
			if(src[i]-'A'<13)
			{
				src[i]+=13;
			}
			else
			{
				src[i]-=13;
			}
		}
		else if(islower(src[i]))
		{
			if(src[i]-'a'<13)
			{
				src[i]+=13;
			}
			else
			{
				src[i]-=13;
			}
		}
		printf("%c",src[i]);
	}
	return 0;
}
