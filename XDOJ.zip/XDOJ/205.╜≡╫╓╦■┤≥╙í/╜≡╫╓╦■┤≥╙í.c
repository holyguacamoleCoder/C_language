#include<stdio.h>
void tow(char a,int N)
{
	int i=0;
	int j=0;
	for(i=1;i<=N;i++)
	{
		for(j=1;j<=(N-i);j++)
		{
			printf(" ");
		}
		for(j=1;j<=i;j++)
		{
			printf("%c",a);
			if(j!=i)
			{
				printf(" ");
			}
		}
		printf("\n");
	}
}


int main()
{
	char a='0';
	int N=0;
	scanf("%c%d",&a,&N);
	tow(a,N);
	return 0;
}
