#include<stdio.h>
int main()
{
	int m,n;
	int i=0,j=0;
	scanf("%d%d",&m,&n);
	int arr[m][n];
	int r_max[m];
	int c_min[n];
	int flag=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&arr[i][j]);
		}
	}
	for(i=0;i<m;i++)//�����
			{
				r_max[i]=arr[i][0];
				for(j=0;j<n;j++)
				{
					if(r_max[i]<arr[i][j])
					{
						//int tmp=row[i];
						r_max[i]=arr[i][j];
						//arr[i][j]=tmp;
					}
				}
			}
			for(j=0;j<n;j++)//����С
			{
				c_min[j]=arr[0][j];
				for(i=0;i<m;i++)
				{
					if(c_min[j]>arr[i][j])
					{
						//int tmp=col[j];
						c_min[j]=arr[i][j];
						//arr[i][j]=tmp;
					}
				}
			}
			for(i=0;i<m;i++)
				{
					for(j=0;j<n;j++)
					{
						if(c_min[j]==arr[i][j] && r_max[i]==arr[i][j])
						{
							printf("%d %d %d\n",i+1,j+1,arr[i][j]);
							flag=1;
						}
					}
				}
	if(flag==0)
	{
		printf("no exist");
	}
	return 0;
}
