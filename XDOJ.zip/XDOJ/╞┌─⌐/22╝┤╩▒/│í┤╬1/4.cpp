//T4 ������1
#include<stdio.h>
int palindrom(int n)
{
	int ans=0;
	while(n)
	{
		ans=ans*10+n%10;
		n/=10;
	}
	return ans;
}
int main()
{
	int n=0;
	int count=0;
	scanf("%d",&n);
	while(n!=palindrom(n))
	{
		n+=palindrom(n);
		count++;
	}
	printf("%d %d",n,count);
	return 0;
}
