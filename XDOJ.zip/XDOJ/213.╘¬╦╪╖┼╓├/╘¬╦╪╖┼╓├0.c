#include<stdio.h>
void place(int *num,int m,int n)
{
	int i=0;
	int j=0;
	for(i=0;i<m*n-1;i++)
	{
		for(j=0;j<m*n-1-i;j++)
		{
			if(*(num+j)>*(num+j+1))
			{
				int tmp=*(num+j);
				*(num+j)=*(num+j+1);
				*(num+j+1)=tmp;
			}
		}
	}
	for(i=0;i<m;i++)
	{
		if(i%2==0)
		{
			for(j=n-1;j>=0;j--)
			{
				printf("%3d",*(num+j));
			}	
			num+=(n);
		}
		else
		{
			for(j=0;j<n;j++)
			{
				printf("%3d",*(num+j));
			}
			num+=(n);
		}
		if(i!=m-1)
		printf("\n");
	}
}

int main()
{
	int m=0,n=0;
	scanf("%d%d",&m,&n);
	int num[50];
	int i=0;
	for(i=0;i<m*n;i++)
	{
		scanf("%d",&num[i]);
	}
	place(num,m,n);
	return 0;
}
