#include<stdio.h>
struct info{
	int id;
	int grades;
	int ballot;
};
int main()
{
	int N=0;
	int i=0,j=0;
	info e[21];
	scanf("%d",&N);
	for(i=0;i<N;i++)
	{
		scanf("%d%d%d",&e[i].id,
					   &e[i].grades,
					   &e[i].ballot);
	}
	for(i=0;i<N-1;i++)
	{
		for(j=0;j<N-i-1;j++)
		{
			if(e[j].ballot<e[j+1].ballot)
			{
				info tmp=e[j];
				e[j]=e[j+1];
				e[j+1]=tmp;
			}
		}
	}
	if(N<4)
	{
		printf("1\n");
		printf("%d %d",e[0].id,e[0].ballot);
	}
	else 
	{
		for(i=0;i<N/4;i++)
		{
			printf("%d\n",N/4);
			printf("%d %d",e[i].id,e[i].ballot);
		}
	}
	return 0;
}
