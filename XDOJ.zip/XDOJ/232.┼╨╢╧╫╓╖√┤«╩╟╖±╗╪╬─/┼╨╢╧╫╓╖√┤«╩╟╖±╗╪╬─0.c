#include<stdio.h>
#include<string.h>
int main()
{
	char a[50];
	char b[50];
	int i=0;
	gets(a);
	int ret=strlen(a);
	*(b+ret)='\0';
	while(*(a+i))
	{
		*(b+ret-1-i)=*(a+i);
		i++;
	}
	if(strcmp(a,b)==0)
	{
		printf("yes");
	}
	else 
	{
		printf("no");
	}
	return 0;
}
