#include<stdio.h>
#include<string.h>
char ox[22]={'0','1','2','3','4','5','6','7','8','9','A','a','B','b','C','c','D','d','E','e','F','f'};
int  dx[22]={0,1,2,3,4,5,6,7,8,9,10,10,11,11,12,12,13,13,14,14,15,15};

int find(int ch)
{
	int i=0;
	for(i=0;i<22;i++)
	{
		if(ch==ox[i])
			return i;
	}
	return -1;
}

int main()
{
	int sum=0;
	int flag=0;
	int i =0;
	char c[51]={0};
	scanf("%s",c);
	int len=(int)strlen(c);
	int pos=0;
	
	for(i=0;i<len;i++)
	{
		pos=find(c[i]);
		if(pos>=0)
		{
			flag=1;
			sum+=dx[pos];
		}
	}
	
	if(flag)
	{
		printf("%d",sum);
	}
	else
	{
		printf("NO");
	}
	return 0;
}
