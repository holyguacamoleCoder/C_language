#include<stdio.h>
void fun(int x)
{
	int i=0,j=0,k=0;
	int y[168];
	for(i=2;i<=x;i++)
	{
		for(j=2;j<=i;j++)
		{
			if(i%j==0)
			break;
		}
		if(j==i)
		{
			y[k++]=i;
		}
	}
	printf("%d\n",k);
	int t=k;
	for(k=0;k<t;k++)
	{
		printf("%d ",y[k]);
	}
	
}

int main()
{
	int x=0;
	scanf("%d",&x);
	fun(x);
	return 0;
}
