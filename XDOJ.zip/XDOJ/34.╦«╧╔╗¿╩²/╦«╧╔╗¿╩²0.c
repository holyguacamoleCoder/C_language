#include<stdio.h>
#include<math.h>
int function(int a, int b)
{
	int i,cnt=0,p,q,r,sum=0,count=0;
	if(a>b)
	{
		int tmp=a;
		a=b;
		b=tmp;
	}
	if(a<100)a=100; 
	for(i=a;i<=b;i++)
	{
		q=i;
		r=i;
		while(q!=0){
			p=q%10;
			cnt++;
			q/=10;
		} 
		while(r!=0){
			p=r%10;
			sum+=pow(p,cnt);
			r/=10; 
		}
		if(sum==i){
			count++;
		}
		sum=0; 
		cnt=0;
	}
	return count;
}
int main(){
	int a,b;
	scanf("%d %d",&a,&b); 
	printf("%d",function(a,b));
}
