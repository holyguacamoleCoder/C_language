#include<stdio.h>
struct Stu{
	int id;
	int grade[5];
	int sum;
};
int main()
{
	int N=0;
	int i=0,j=0;
	scanf("%d",&N);
	int count_stu=0;//��¼����
	int count=0;//��¼����ѧ����
	Stu info[N];
	for(i=0;i<N;i++)
	{
		scanf("%d",&info[i].id);
		info[i].sum=0;
		for(j=0;j<5;j++)
		{
			scanf("%d",&info[i].grade[j]);
			info[i].sum+=info[i].grade[j];	
		}
	}
	int grade_max=0;
	for(i=0;i<N-1;i++)
	{
		if(info[grade_max].sum<=info[i].sum)
		{
			grade_max=i;
		}
	}
	printf("%d %d\n",info[grade_max].id,
					 info[grade_max].sum);
	for(i=0;i<N;i++)
	{
		count=0;
		for(j=0;j<5;j++)
		{
			if(info[i].grade[j]>=90)
			{
				count_stu++;
			}
		}
		if(count_stu>=3)
		{
			count++;
		}
	}
	printf("%d",count);
	return 0;
}
