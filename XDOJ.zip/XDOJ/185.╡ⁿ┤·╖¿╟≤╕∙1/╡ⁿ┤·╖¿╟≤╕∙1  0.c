#include<stdio.h>
#include<math.h>
int main()
{
	double a=0;
	scanf("%lf",&a);
	double x=1;
	double y=(x+a*1.0/x)/2.0;
	while(fabs(y-x)>=pow(10,-5))
	{
		x=y;
		y=(x+a*1.0/x)/2.0;
	}
	printf("%.5lf",y);
	return 0;
}
