#include<stdio.h>
double f1(double x)
{
	return 2.0*x+9;
}
double f2(double x)
{
	return 7.0*(x+1)*(x+1)+9.0*x;
}
double f3(double x)
{
	return 7.0*x*x*x/22.0-8;
}
double d_f2(double x)
{
	return 14.0*(1+x)+9;
}
double d_f3(double x)
{
	return 21.0*x*x/22.0;
}
int main()
{
	double x=0;
	scanf("%lf",&x);
	
	double y1=f1(x);
	double y2=f2(x);
	double y3=f3(x);
	

	
	if(x<0)
	{
		double d_y1=2;
		double d_y2=d_f2(x);
		double d_y3=d_f3(x);
		double min=d_y1;
		if(min>d_y2)
		{
			min=d_y2;
		}
		if(min>d_y3)
		{
			min=d_y3;
		}
		printf("%.2lf",min);
	}
	else if(x>=0 && x<10)
	{
		double max=y1;
		if(max<y2)
		{
			max=y2;
		}
		if(max<y3)
		{
			max=y3;
		}
		printf("%.2lf",max);
	}
	else
	{
		double sum=y1+y2+y3;
		printf("%.2lf",sum);	
	}
	return 0;
}
