#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main()
{
	char password[20];
	int i=0;
	gets(password);
	int len=strlen(password);
	for(i=0;i<len;i++)
	{
		if(isupper(password[i]))
		{
			password[i]=tolower(password[i]);
		}
		else if(islower(password[i]))
		{
			password[i]=toupper(password[i]);
		}
		else if(password[i]==' ')
		{
			password[i]='#';
		}
		else if(password[i]>=48 &&password[i]<=57)
		{
			int ch=password[i]+2-'0';
			if(ch>=10)
			{
				password[i]=ch%10+48;
			}
			else
			{
				password[i]=ch+48;
			}
		}
	}
	for(i=0;i<len;i++)
	{
		printf("%c",password[i]);
	}
	return 0;
}
