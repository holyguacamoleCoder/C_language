#include<stdio.h>
int is_up(int (*arr)[50],int n)
{
	int i=0,j=0;
	int flag=1;
	for(i=1;i<n;i++)
	{
		for(j=0;j<i;j++)
		{
			if(arr[i][j]!=0)
			{
				flag=0;
			}
		}	
	}
	return flag;
}
int is_down(int (*arr)[50],int n)
{
	int i=0,j=0;
	int flag=1;
	for(i=0;i<n;i++)
	{
		for(j=n-1;j>i;j--)
		{
			if(arr[i][j]!=0)
			{
				flag=0;
			}
		}
	}
	return flag;
}
int main()
{
	int n=0;
	int i=0,j=0;
	scanf("%d",&n);
	int arr[50][50];
	//����
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&arr[i][j]);
		}
	}
	//judge
	int up=is_up(arr,n);
	int down=is_down(arr,n);
	if(up&&down)
		printf("PD");
	else if(up)
		printf("UP");
	else if(down)
		printf("DOWN");	
	else
	//������
		printf("NO");
	return 0;
}
