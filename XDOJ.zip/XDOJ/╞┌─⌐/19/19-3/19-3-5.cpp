#include<stdio.h>
struct Stu{
	int id;
	int all_times;
	int in_times;
	int work_times;
	int absent;
	int forbiden=0;
};
int main()
{
	int N=0;
	int i=0;
	int count=0;
	scanf("%d",&N);
	Stu info[N];
	for(i=0;i<N;i++)
	{
		scanf("%d%d%d%d",&info[i].id,
						 &info[i].all_times,
						 &info[i].in_times,
						 &info[i].work_times);
		info[i].absent=info[i].all_times-info[i].in_times;
		if(info[i].absent>=info[i].all_times*0.25 &&
		  info[i].work_times<info[i].all_times*0.5)
		  {
		  	info[i].forbiden=1;
		  	count++;
		  }
	}
	printf("%d\n",count);
	if(count==0)
	{
		printf("No");
	}
	else
	{
		for(i=0;i<N;i++)
		{
			if(info[i].forbiden==1)
			{
				printf("%d\n",info[i].id);
			}
		}
	}
	return 0;
}
