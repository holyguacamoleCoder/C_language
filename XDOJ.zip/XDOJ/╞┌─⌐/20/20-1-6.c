#include<stdio.h>
int main()
{
	int m,n;
	int odd=0,even=0,spe=0,max=0;
	int i=0;
	scanf("%d%d",&m,&n);
	for(i=m;i<=n;i++)
	{
		if(i%2==0)
			even++;
		else
			odd++;
		if(i%7==0 && i%3!=0)
			spe++;
	}
	if(even>odd)
		max=even;
	else
		max=odd;
	if(spe>max)
		max=spe;
	printf("%d %d %d\n%d",odd,even,spe,max);
	return 0;
}
