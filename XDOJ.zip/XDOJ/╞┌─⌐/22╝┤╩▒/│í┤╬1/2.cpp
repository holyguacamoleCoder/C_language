//T2  ������
#include<stdio.h>
int main()
{
	int n=0;
	int i=0,j=0;
	scanf("%d",&n);
	int A[n][n];
	int B[n][n];
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&A[i][j]);
			if(i<j)
			{
				B[i][j]=A[i][j]+1;
			}
			else if(i>j)
			{
				B[i][j]=A[i][j]-1;
			}
			else
			{
				B[i][j]=A[i][j];
			}
		}
	}
	struct max{
		int value;
		int row;
		int col;
	};
	max max_B;
	max_B.value=B[0][0];
	max_B.row=0;
	max_B.col=0;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(B[i][j]>max_B.value)
			{
				max_B.value=B[i][j];
				max_B.row=i;
				max_B.col=j;
			}
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",B[i][j]);
		}
		printf("\n");
	}
	printf("a[%d][%d]=%d\n",max_B.row,
						  max_B.col,
						  max_B.value);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",B[i][j]*max_B.value);
		}
		printf("\n");
	}
	return 0;
}
