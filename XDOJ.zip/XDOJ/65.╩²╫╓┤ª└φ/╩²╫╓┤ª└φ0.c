#include<stdio.h>
int deal(int n)
{
	int sum=0;
	int t=n;
	do{
		sum+=t%10;
		t/=10;
	}while(t!=0);
	if(sum<10)
	{
		return sum;
	}
	else
	{
		return deal(sum);
	}
}
int main()
{
	int n=0;
	scanf("%d",&n);
	printf("%d",deal(n));
	return 0;
}
