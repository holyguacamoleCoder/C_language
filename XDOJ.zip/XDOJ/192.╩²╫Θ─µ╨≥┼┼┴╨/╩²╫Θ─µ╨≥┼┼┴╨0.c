#include<stdio.h>
int main()
{
	int i=0;
	int left=0;
	int right=4;
	int arr[5];
	for(i=0;i<5;i++)
	{
		scanf("%d,",&arr[i]);
	}
	while(left<=right)
	{
		int tmp=arr[left];
		arr[left]=arr[right];
		arr[right]=tmp;
		left++;
		right--;
	}
	for(i=0;i<5;i++)
	{
		printf("%d ",arr[i]);
	}
	return 0;
}
