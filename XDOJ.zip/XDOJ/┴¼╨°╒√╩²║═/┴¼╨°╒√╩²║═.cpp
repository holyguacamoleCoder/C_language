#include<stdio.h>
//int main()
//{
//	int N=0;
//	scanf("%d",&N);
//	int i ,j , k, sum ,iCount = 1;
//	int temp;
//	for(i = 1;i <= N / 2;i++)
//	{
//		for(j = i + 1;j < N;j++)
//		{
//			sum = 0;
//			for(k = i;k < j;k++)
//			{
//				sum += k;
//			}
//			if(sum == N) 
//			{
//				iCount++;
//				printf("[");
//				temp = i;
//				while(temp != j)
//				{
//					printf("%d,",temp++);
//					if(j - temp == 1)
//					{
//						printf("%d]\n",temp++);
//					}	
//				} 
//			}
//		}
//	}
//	printf("[%d]\n",N); 
//	printf("%d",iCount);
//	return 0;
//
//}

//void output(int n,int j)
//{
//	int sum=0;
//	while(sum!=n)
//	{
//	sum+=j;
//	printf("%d  ",j++);
//	}
//	printf("\n");
//}
//
//int main(void)
//{
//	int n;
//	int i,j=1;
//	int sum,right;
//	int exist=0;
//	printf("please input a number:");
//	scanf("%d",&n);
//	for(j=1;j<n;j++)
//	{
//		right=0;
//		sum=0;
//		for(i=j;i<=n;i++)
//		{
//			sum+=i;
//			if(sum==n)
//			{
//				right=1;
//				break;
//			}
//			else if(sum>n)
//			{
//				break;
//			}
//		}
//		if(right==1)
//		{
//			exist++;
//			output(n,j);
//		}
//	}
//	if(exist==0)
//	{
//	printf("NONE\n");
//	}
//	return 0;
//	}
void output(int n,int j)
{
	int sum=0;
	while(sum!=n)
	{
		printf("%d ",j);
		sum+=j;
		j++;
	}
	printf("\n");
}
int main()
{
	int n=0;
	int i=0,j=0;
	scanf("%d",&n);
	int sum=0;
	int exist=0;
	int right=0;
	for(j=1;j<n;j++)
	{
		sum=0;
		right=0;
		for(i=j;i<=n;i++)
		{
			sum+=i;
			if(sum==n)
			{
				right=1;
				break;
			}
			else if(sum>n)
			{
				break;
			}
		}
		if(right==1)
		{
			exist++;
			output(n,j);
		}
	}
	if(exist==0)
	{
		printf("no");
	}
	return 0;
}
