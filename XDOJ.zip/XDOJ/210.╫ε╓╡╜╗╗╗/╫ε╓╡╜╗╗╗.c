#include<stdio.h>
void change(int *p,int n)
{
	int j,max=-1,min=*p,flag1=0,flag2=0,t;
	for(j=0;j<n;j++)
	{
		if(*(p+j)>max)
		{
			max=*(p+j);
		    flag1=j;
		}
		if(*(p+j)<min)
		{
			min=*(p+j);
		    flag2=j;
		}
	}
	t=*(p+flag1);
	*(p+flag1)=*(p+flag2);
	*(p+flag2)=t;
}
int main()
{
	int num[20]={0};
	int n,i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&num[i]);
	}
	change(num,n);
	for(i=0;i<n;i++)
	{
		printf("%d ",num[i]);
	}
	return 0;
}
