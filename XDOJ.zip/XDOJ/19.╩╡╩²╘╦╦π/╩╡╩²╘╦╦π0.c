#include<stdio.h>
int main()
{
	float a,b,h;
	scanf("%f %f %f",&a,&b,&h);
	printf("%.3f",a*b*h);
	return 0;
}
