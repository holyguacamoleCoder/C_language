//T3 ʱ�䴦��
#include <stdio.h>
typedef struct {
	int hour;//0~23;
	int minute;//O~59
	int second;//O~59
} TIME;
int adjust (TIME *now, TIME *delta,int direction)
{
	int same_day=0;
	now->hour=now->hour+direction*delta->hour;
	now->minute=now->minute+direction*delta->minute;
	now->second=now->second+direction*delta->second;
	if(now->second>=60 || now->second<0)
	{
		now->minute=now->minute+now->second/60.0;
		now->second=now->second-direction*60;
		if(now->minute>=60 || now->minute<0)
		{
			now->hour=now->hour+now->minute/60.0;
			now->minute=now->minute-direction*60;
			if(now->hour>=24)
			{
				same_day=1;
				now->hour=now->hour%24;
			}
			else if(now->hour<0)
			{
				same_day=1;
				now->hour=24+now->hour%24;
			}
		}
	}

	return same_day;
}
int main() {
	TIME now, delta;
	int direction;
	scanf("%d", &direction);
	scanf("%d %d %d", &now.hour, &now.minute, &now.second);
	scanf("%d %d %d", &delta.hour, &delta.minute, &delta.second);
	int same_day;
	same_day = adjust(&now, &delta, direction);
	printf("%d %d %d %d", same_day, now.hour, now.minute, now.second);
	return 0;
}
