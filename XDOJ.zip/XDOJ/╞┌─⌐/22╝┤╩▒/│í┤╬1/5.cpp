#include<stdio.h>
int main()
{
	int n,t;
	int i=0,j=0;
	scanf("%d%d",&n,&t);
	int arr[n];
	int sum=0;
	int invalid=0;
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	int min=0;
	int max=0;
	for(i=0;i<n;i++)
	{
		if(arr[min]>arr[i])
		{
			min=i;
		}
		else if(arr[max]<arr[i])
		{
			max=i;
		}
	}
	for(i=0;i<n;i++)
	{
		if(max==i && max!=t-1)
		{
			invalid++;
			continue;
		}
		if(min==i && min!=t-1)
		{
			invalid++;
			continue;
		}
		sum+=arr[i];
	}
	n-=invalid;
	float aver=sum*1.0/n;
	printf("%.2f",aver);
	return 0;
}
