#include<stdio.h>
int fib(int n)
{
	if(n==1 || n==2)
		return 1;
	return fib(n-1) + fib(n-2);
}
int Prime(int n)
{
	for(int i=2;i<=n/2;i++)
	{
		if(n%i == 0)
			return 0;
	} 
	return 1;
}
int main()
{
	int n, m;
	scanf("%d",&n);
	
	m = fib(n);
	
	if(Prime(m) == 0)
	{
		printf("%d",m);
	}
	else printf("yes");
	
	return 0;
}
