#include<stdio.h>

struct Stu 
{
	char id[20];
	int sg;
	int eg;
};

int main()
{
	int i=0,j=0;
	int m=0;
	int n=0;
	scanf("%d%d",&m,&n);
	struct Stu s[m];
	for(i=0;i<m;i++)
	{
		scanf("%s%d%d",s[i].id,
					   &s[i].sg,
					   &s[i].eg);
	}
	for(i=0;i<m-1;i++)
	{
		for(j=0;j<m-i-1;j++)
		{
			if(s[j].sg<s[j+1].sg)
			{
				struct Stu tmp=s[j];
				s[j]=s[j+1];
				s[j+1]=tmp;
			}
			else if(s[j].sg==s[j+1].sg)
			{
				if(s[j].eg<s[j+1].eg)
				{
					struct Stu ret=s[j];
					s[j]=s[j+1];
					s[j+1]=ret;	
				}
			}
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%s %d %d\n",s[i].id,
							s[i].sg,
							s[i].eg);
	}
	return 0;
}
