#include<stdio.h>
struct max{
	int row;
	int col;
	int value;
};
int main()
{
	int m,n;
	int i=0,j=0;
	int mat[51][51];
	scanf("%d%d",&m,&n);
	max info_c[49];
	max info_r[49];
	int count1=0,count2=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&mat[i][j]);
		}
	}
	for(i=1;i<m-1;i++)
	{
		for(j=1;j<n-1;j++)
		{
			if(mat[i][j]>mat[i-1][j] && 
			   mat[i][j]>mat[i+1][j])//�м���
			{
				info_c[count1].col=j;
				info_c[count1].row=i;
				info_c[count1].value=mat[i][j];
				count1++;	
			}
			if(mat[i][j]>mat[i][j-1] && 
				mat[i][j]>mat[i][j+1])//�м���
			{
				info_r[count2].col=j;
				info_r[count2].row=i;
				info_r[count2].value=mat[i][j];	
				count2++;
			}
		}
	}
	if(count1>0&&count2>0)
	{
		for(i=0;i<count1;i++)
		{
			for(j=0;j<count2;j++)
			{
				if(info_c[i].col==info_r[j].col &&
				  info_c[i].row==info_r[j].row &&
				  info_c[i].value==info_r[j].value)
				{
					printf("%d %d %d\n",info_c[j].value,
									  info_c[j].row+1,
									  info_c[j].col+1);
				}
			}
		}
	}
	else
	{
		printf("None %d %d",m,n);
	}
	return 0;
//	4 5
//	1 1 1 1 1
//	1 3 9 3 1
//	1 5 3 5 1
//	1 1 0 1 1
}
