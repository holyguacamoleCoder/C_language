#include<stdio.h>

struct Stu 
{
	int id;
	char name[10]; 
	int g1;
	int g2;
	int g3;
	float aver;
};


int main()
{
	int i=0,j=0;	
	int N=0;
	scanf("%d",&N);
	struct Stu s[N];
	for(i=0;i<N;i++)
	{
		scanf("%d",&s[i].id);
		scanf("%s",s[i].name);
		scanf("%d",&s[i].g1);
		scanf("%d",&s[i].g2);
		scanf("%d",&s[i].g3);
		s[i].aver=(s[i].g1+s[i].g2+s[i].g3)*1.0/3;
	}
	for(i=0;i<N-1;i++)
	{
		for(j=0;j<N-1-i;j++)
		{
			if(s[j].aver<s[j+1].aver)
			{
				struct Stu tmp=s[j];
				s[j]=s[j+1];
				s[j+1]=tmp;
			}
			else if(s[j].aver==s[j+1].aver)
			{
				if(s[j].id>s[j+1].id)
				{
					struct Stu ret=s[j];
					s[j]=s[j+1];
					s[j+1]=ret;	
				}
			}
		}
	}
	for(i=0;i<N;i++)
	{
		printf("%d %s %.1f",
				s[i].id,
				s[i].name,
				s[i].aver);
		printf("\n");
	}
	return 0; 
}
