#include<stdio.h>
int main()
{
	int n = 0;
	int i = 0;
	int k = 0;
	int max = 0;
	int min = 0;
	int d[10] = { 0 };
	scanf("%d", &n);
	do
	{
		d[i] = n % 10;
		n /= 10;
		i++;
	} while (n);
	for (k = 0; k < i; k++)
	{
		if (d[k] > d[max])
		{
			max = k;
		}
		if (d[k] < d[min])
		{
			min = k;
		}
	}
	printf("%d %d %d", i, d[max], d[min]);
	return 0;
}
