#include<stdio.h>
int main()
{
	int N=0;
	int i=0;
	int A[80];
	scanf("%d",&N);
	for(i=0;i<N;i++)
	{
		scanf("%d",&A[i]);
	}
	int max=0;
	for(i=0;i<N;i++)
	{
		if(A[max]<A[i])
		{
			max=i;
		}
	}
	printf("%d %d %d",N,A[max],max);
	return 0;
}
