#include<stdio.h>

struct Stu
{
	char name[20];
	int g[6];
	int sum_g;
};

int main()
{
	int i=0,j=0;
	int N=0;
	scanf("%d",&N);
	struct Stu s[N];
	for(i=0;i<N;i++)
	{
		s[i].sum_g=0;
		scanf("%s",s[i].name);
		for(j=0;j<6;j++)
		{
			scanf("%d",&s[i].g[j]);
			s[i].sum_g+=s[i].g[j];
		}
	}
	for(i=0;i<N-1;i++)
	{
		for(j=0;j<N-1-i;j++)
		{
			if(s[j].sum_g<s[j+1].sum_g)
			{
				struct Stu tmp=s[j];
				s[j]=s[j+1];
				s[j+1]=tmp;
			}
			else if(s[j].sum_g==s[j+1].sum_g)
			{
				if(s[j].g[5]<s[j+1].g[5])
				{
					struct Stu ret=s[j];
					s[j]=s[j+1];
					s[j+1]=ret;	
				}
			}
		}
	}
	for(i=0;i<N;i++)
	{
		printf("%s %d %d\n",
				s[i].name,
				s[i].sum_g,
				s[i].g[5]);
	}
	return 0;
}
