#include<stdio.h>
int fac(int n)
{
	int i=0;
	int fac=1;
	for(i=1;i<=n;i++)
	{
		fac*=i;
	}
	return fac;
}
float P(int m,int n)
{
	return fac(m)/fac(m-n)*1.0/fac(n);
}
int main()
{
	int m=0;
	int n=0;
	scanf("%d%d",&m,&n);
	printf("%.2f",P(m,n));
	return 0;
}
