#include<stdio.h>
#define A 31
#define B 30
#define C 29
#define D 28
int main()
{
	int a=0;
	int b=0;
	int date=0;
	scanf("%d %d",&a,&b);
	switch(b)
	{
		case 1: case 3: case 5: case 7:
		case 8: case 10: case 12:
			date=A;
			break;
		case 2:
			if((a%4==0 && a%100!=0) || a%400==0)
			{
				date=C;
				break;
			}
			else
			{
				date=D;
				break;
			}
		case 4: case 6: case 9: case 11:
			date=B;	
	}

	printf("%d",date);
	return 0;
}
