//T2 ��ֵ����
#include<stdio.h>
int main()
{
	int n=0;
	int i=0;
	scanf("%d",&n);
	int arr[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	struct dict{
		int vaule;
		int position;
	};
	dict min;
	dict max;
	max.vaule=arr[0];
	max.position=0;
	for(i=0;i<n;i++)
	{
		
		if(max.vaule<arr[i])
		{
			if(max.position!=i)
			{ 
				max.vaule=arr[i];
				max.position=i;	
			}
		}
	}
	arr[max.position]=arr[0];
	arr[0]=max.vaule;
	
	
	min.vaule=arr[1];
	min.position=1;
	for(i=0;i<n;i++)
	{
		if(min.vaule>arr[i])
		{
						
			if(min.position!=i)
			{
				min.vaule=arr[i];
				min.position=i;
			}
		}
	}
	arr[min.position]=arr[n-1];
	arr[n-1]=min.vaule;
	
	for(i=0;i<n;i++)
	{
		printf("%d ",arr[i]);
	}
	return 0;
}
