#include<stdio.h>
int main()
{
	float power=0;
	float tax=0;
	float ex=0;
	char rank;
	scanf("%f",&power);
	if(power<=110)
	{
		tax=0.5*power;
		rank='A';
		ex=0;
	}
	else if(power>110 && power<=210)
	{
		tax=55+0.55*(power-110);
		rank='B';
		ex=power-110;
	}
	else
	{
		tax=110+0.70*(power-210);
		rank='C'; 
		ex=power-210;
	}
	printf("%.2f %c %.2f",tax,rank,ex);
	return 0;
}
