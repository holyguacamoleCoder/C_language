#include<stdio.h>
int main()
{
	int n;
	int i=0;
	scanf("%d",&n);
	int even=0,odd=0,th_nf=0,min=0;
	for(i=n;i<=5*n;i++)
	{
		if(i%2==0)
			even++;
		else
			odd++;
		if(i%3==0 && i%5!=0)
			th_nf++;
	}
	if(even<odd)
		min=even;
	else
		min=odd;
	if(th_nf<min)
		min=th_nf;
	printf("%d %d %d\n%d",odd,even,th_nf,min);
	return 0;
}
