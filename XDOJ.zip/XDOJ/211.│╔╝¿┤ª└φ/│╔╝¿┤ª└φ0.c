#include<stdio.h>
float aver(int(*stu)[4])
{
	int sum=0;
	for(int i=0;i<5;i++)
	{
		sum+=*(stu+i)[0];
	}
	return sum*1.0/5;
}

int fals(int stu[5][4])
{
	int i=0,j=0;
	int c1=0;
	int c2=0;
	for(i=0;i<5;i++)
	{
		c2=0;
		for(j=0;j<4;j++)
		{
			if(stu[i][j]<60)
			{
				c2++;
			}
		}
		if(c2>=2)
		{
			c1++;
		}
	}
	return c1;
}


int well(int stu[5][4])
{
	int c1=0;
	int c2=0;
	int i=0,j=0;
	int sum=0;
	float aver=0;
	for(i=0;i<5;i++)
	{
		c2=0;
		sum=0;
		for(j=0;j<4;j++)
		{
			sum+=stu[i][j];
			if(stu[i][j]>=85)
			{
				c2++;
			}
		}
		aver=sum*1.0/4;
		if(aver>=90 || c2==4)
		{
			c1++;
		}
	}
	return c1;
}

int main()
{
	int stu[5][4];
	int i=0,j=0;
	for(i=0;i<5;i++)
	{
		for(j=0;j<4;j++)
		{
			scanf("%d",&stu[i][j]);
		}
	}
	printf("%.1f ",aver(stu));
	printf("%d ",fals(stu));
	printf("%d",well(stu));
	return 0;
}
