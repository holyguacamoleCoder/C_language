#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	if(a%2==0)
	{
		printf("ż��");
	}
	else if(a%2==1)
	{
		printf("����");
	}
	return 0;
}
