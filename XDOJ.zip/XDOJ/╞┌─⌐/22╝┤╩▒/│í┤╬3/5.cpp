#include <stdio.h>
#include <string.h>

typedef struct {
	int length; // �ַ�������,0-99
	char data[150]; // �ַ����ݣ����������ַ�'\0'
} FIXED_STRING;

char *insert(FIXED_STRING *s, char *t, int pos)
{
	int i=0;
	int len=strlen(t);
	char ans[170];
	for(i=0;i<s->length+len;i++)
	{
		if(i<pos)
		{
			ans[i]=s->data[i];
		}
		else if(i<pos+len)
		{
			ans[i]=t[i-pos];
		}
		else
		{
			ans[i]=s->data[i-pos];
		}
		s->data[i]=ans[i];
	}
	s->data[i]='\0';
	s->length+=len;
	return s->data;
}

int main() {
	FIXED_STRING s;
	char t[20];
	scanf("%s", s.data);
	s.length = strlen(s.data);
	scanf("%s", t);
	int pos;
	scanf("%d", &pos);
	char *ps = insert(&s, t, pos);
	printf("%d %s\n", s.length, ps);
	return 0;
}
