#include<stdio.h>
char*fun(char*str1,char*str2)
{
	char*ret=str1;
	while(*str1)
	{
		str1++;
	}
	while(*str1++=*str2++);
	return ret;
}

int main()
{
	char s1[100],s2[100];
	gets(s1);
	gets(s2);
	printf("%s",fun(s1,s2));
	return 0;
}
