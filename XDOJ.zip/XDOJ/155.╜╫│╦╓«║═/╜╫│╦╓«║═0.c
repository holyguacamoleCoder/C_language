#include<stdio.h>
int main()
{
	int N=0;
	scanf("%d",&N);
	int i=0;
	int j=0;
	int sum=0;
	int ret=0;
	for(i=1;i<=N;i++)
	{
		ret=1;
		for(j=1;j<=i;j++)
		{
			ret*=j;
		}
		sum+=ret;
	}
	printf("%d %d %d",N,ret,sum);
	return 0;
}
