#include<stdio.h>
#include<string.h>
int main()
{
	int m=0;
	char str[50];
	gets(str);
	scanf("%d",&m);
	int len=strlen(str);
	if(len<m)
	{
		printf("error");
	}
	else 
	{
		printf("%s",str+m-1);
	}
	return 0;
}
