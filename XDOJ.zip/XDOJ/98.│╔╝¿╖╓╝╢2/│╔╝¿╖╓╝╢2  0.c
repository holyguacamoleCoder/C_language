#include<stdio.h>
int main()
{
	float m=0;
	scanf("%f",&m);
	if(m>=90)
	{
		printf("%.2f %c",m,'A');
	}
	else if(m>=80 && m<=89)
	{
		printf("%.2f %c",m,'B');
	}
	else if(m>=70 && m<=79)
	{
		printf("%.2f %c",m,'C');
	}
	else if(m>=60 && m<=69)
	{
		printf("%.2f %c",m,'D');
	}
	else
	{
		printf("%.2f %c",m,'E');
	}
	return 0;
}
