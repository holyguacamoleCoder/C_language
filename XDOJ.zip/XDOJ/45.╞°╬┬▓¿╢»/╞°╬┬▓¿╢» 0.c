#include<stdio.h>
#include<math.h>
int main()
{
	int n = 0;
	int i = 0;
	int j = 0;
	int temp[31] = { 0 };
	int D_v[30] = { 0 };
	int max = 0;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &temp[i]);
		
	}
	for (int j = 0; j < n-1; j++)
	{
		D_v[j] = temp[j+1] - temp[j];
		if (abs(D_v[j]) >=abs(D_v[max]))
		{
			max = j;
		}
	}
	printf("%d",abs(D_v[max]));
	return 0;
}
