#include<stdio.h>
int main()
{
	int a;
	char b;
	scanf("%d,%c",&a,&b);
	printf("%d,%c",a+b,a+b);
	return 0;
}
