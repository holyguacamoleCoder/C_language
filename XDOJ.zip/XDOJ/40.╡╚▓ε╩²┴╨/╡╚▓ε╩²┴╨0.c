#include<stdio.h>
#include<math.h>
int main()
{
	int n=0;
	int i=0;
	int j=0;
	int num=0;
	int d_vaule[98]={0};
	int arr[99]={0};
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1;j++)
		{
			if(arr[j]>arr[j+1])
			{
				int tmp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=tmp;
				
			}
		}
	}
	for(j=0;j<n-1;j++)
	{
		d_vaule[j]=arr[j+1]-arr[j];
	}
	for(i=0;i<n-2;i++)
	{
		if(d_vaule[i]==d_vaule[i+1])
		num++;
	}
	if(num==n-2)
	{
		printf("%d",abs(d_vaule[0]));
	}
	else
	{
		printf("no");
	}
	return 0;
}
