#include<stdio.h>
void buble_sort(int arr[],int sz)
{
	int i=0;
	int j=0;
	for(i=0;i<sz-1;i++)
	{
		for(j=0;j<sz-1;j++)
		{
			if(arr[j]<arr[j+1])
			{
				int tmp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=tmp;
			}
		}
	}
}

void print(int arr[],int sz)
{
	int i=0;
	for(i=0;i<sz;i++)
		{
			printf("%d ",arr[i]);
		}
}
int main()
{
	int n=0;
	int i=0;
	int j=0;
	int k=0;
	int num=0;
	int even[100]={0};
	int odd[100]={0};
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&num);
		if(num%2==0)
		{
			even[j]=num;
			j++;
		}
		else
		{
			odd[k]=num;
			k++;
		}
	}
	buble_sort(even,j);
	buble_sort(odd,k);
	print(even,j);
	print(odd,k);
	return 0;
}
