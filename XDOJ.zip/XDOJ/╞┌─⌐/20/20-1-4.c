#include<stdio.h>
int main()
{
	int m;
	int i=0;
	scanf("%d",&m);
	int evsum=0,odsum=0,fi_nt=0,max=0;
	for(i=1;i<m;i++)
	{
		if(i%2==0)
			evsum+=i;
		else
			odsum+=i;
		if(i%5==0 && i%3!=0)
			fi_nt+=i;
	}
	if(evsum>odsum)
		max=evsum;
	else
		max=odsum;
	if(fi_nt>max)
		max=fi_nt;
	printf("%d %d %d\n%d",odsum,evsum,fi_nt,max);
	return 0;
}
