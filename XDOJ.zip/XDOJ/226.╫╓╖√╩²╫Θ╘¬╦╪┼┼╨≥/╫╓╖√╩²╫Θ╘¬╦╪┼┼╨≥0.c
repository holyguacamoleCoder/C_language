#include<stdio.h>
#include<string.h>
int main()
{
	char str[100];
	gets(str);
	int i=0;
	int j=0;
	for(i=0;i<(int)strlen(str)-1;i++)
	{
		for(j=0;j<(int)strlen(str)-i-1;j++)
		{
			if(str[j]>str[j+1])
			{
				char tmp=str[j];
				str[j]=str[j+1];
				str[j+1]=tmp;
			}
		}
	}
	printf("%s",str);
	return 0;
}
