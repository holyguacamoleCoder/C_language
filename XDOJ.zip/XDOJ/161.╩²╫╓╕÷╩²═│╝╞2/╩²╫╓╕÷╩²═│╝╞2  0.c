#include<stdio.h>
int Odd(int n)
{
	if(n%2==1)
	return (n+1)/2;
	else
	return n/2;
}
int Even(int n)
{
	if(n%2==1)
	return (n-1)/2;
	else
	return n/2;
}
int Sum_3(int n)
{
	int i=0;
	int count=0;
	for(i=3;i<=n;i+=3)
	{
		if(i%3==0)
		count++;
	}
	return count;
}
int Sum_5(int n)
{
	int i=0;
	int count=0;
	for(i=5;i<=n;i+=5)
	{
		if(i%5==0)
		count++;
	}
	return count;
}
int Sum_7(int n)
{
	int i=0;
	int count=0;
	for(i=7;i<=n;i+=7)
	{
		if(i%7==0)
		count++;
	}
	return count;
}
int main()
{
	int N=0;
	scanf("%d",&N);
	printf("%d %d %d %d %d",Odd(N),Even(N),Sum_3(N),Sum_5(N),Sum_7(N));
	return 0;
}
