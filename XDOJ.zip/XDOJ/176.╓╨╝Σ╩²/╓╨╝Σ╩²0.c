#include<stdio.h>
int main()
{
	int n,i,j;
	int temp=-1,sma,big;
	int a[1000];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
    for(i=0;i<n;i++)
	{
	    sma=0;
	    big=0;
		for(j=0;j<n;j++)
		{
			if(a[i]>a[j])
			sma++;
			else if(a[i]<a[j])
			big++;
		}
		if(big==sma)
		{
			temp=a[i];
			break;
		}	
	}
	printf("%d",temp);
	return 0;
}
