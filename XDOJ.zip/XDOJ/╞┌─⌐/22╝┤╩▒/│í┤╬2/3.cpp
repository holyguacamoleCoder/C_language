//T3 �������
#include<stdio.h>
int main()
{
	int n;
	int i=0;
	scanf("%d",&n);
	struct coord{
		int x;
		int y;
		int dpp;
		int ddi;
		int flag;
	};
	coord info[n];
	for(i=0;i<n;i++)
	{
		scanf("%d%d",&info[i].x,&info[i].y);
		info[i].dpp=(4-info[i].x)*(4-info[i].x)
					+(4-info[i].y)*(4-info[i].y);
		info[i].ddi=(4+info[i].x)*(4+info[i].x)
							+(4+info[i].y)*(4+info[i].y);
		if(info[i].dpp>info[i].ddi)
		{
			info[i].flag=1;
		}
		else
		{
			info[i].flag=0;
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d\n",info[i].flag);
	}
	return 0;
}
