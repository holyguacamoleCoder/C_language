#include <stdio.h>
 
float function(int n) 
{
	int i;
	float a, b, c, sum = 0;
	for (i = 1; i <= n; i++) 
	{
		if (i == 1) 
		{
			a = 2;
			b = 1;
		} 
		else if (i == 2) 
		{
			a = 3;
			b = 2;
		} 
		else 
		{
			c = b;
			b = a;
			a = b + c;
		}
		sum += a / b;
	}
	return (sum);
}
 
int main() 
{
	int n;
	scanf("%d", &n);
	printf("%.2f", function(n));
	return 0;
}
