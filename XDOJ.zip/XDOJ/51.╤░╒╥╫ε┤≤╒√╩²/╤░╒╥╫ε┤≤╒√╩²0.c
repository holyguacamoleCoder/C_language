#include<stdio.h>
int main()
{
	int arr[4] = { 0 };
	int i = 0;
	int j = 0;
	int max = 0;
	for (i = 0; i < 4; i++)
	{
		scanf("%d", &arr[i]);
	}
	for (j = 0; j < 4; j++)
	{
		if (arr[j] > arr[max])
			max = j;
	}
	printf("%d", arr[max]);
	return 0;
}
