#include<stdio.h>
int main()
{
	float r,v,pi=3.14;
	scanf("%f",&r);
	v=4*pi*r*r*r/3.0;
	printf("%.2f",v);
	return 0;
}
