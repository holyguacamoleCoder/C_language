#include<stdio.h>
int main()
{
	int prof=0;
	int bonu=0;
	scanf("%d",&prof);
	if(prof<=100000)
	{
		bonu=0.1*prof;
	}
	else if(prof>100000 && prof<=200000)
	{
		bonu=10000+(prof-100000)*0.075;
	}
	else if(prof>200000 && prof<=400000)
	{
		bonu=17500+(prof-200000)*0.05;
	}
	else if(prof>400000 && prof<=600000)
	{
		bonu=27500+(prof-400000)*0.03;
	}
	else if(prof>600000 && prof<=1000000)
	{
		bonu=33500+(prof-600000)*0.015;
	}
	else
	{
		bonu=39500+(prof-1000000)*0.01;
	}
	printf("%d",bonu);
	return 0;
}
