#include<stdio.h>
#include<string.h>
int main()
{
	int M=0;
	char str[50];
	gets(str);
	scanf("%d",&M);
	printf("%s",str+M+1);
	return 0;
}
