//T1 ��ά�������д���
#include<stdio.h>
void r_sort(int (*a)[5])
{
	int i=0,j=0,k=0;
	for(i=0;i<5;i++)
	{
		for(k=0;k<4;k++)
		{
			for(j=0;j<4-k;j++)
			{
				if(a[i][j]>a[i][j+1])
				{
					int tmp=a[i][j];
					a[i][j]=a[i][j+1];
					a[i][j+1]=tmp;
				}
			}
		}
	}
}
void c_sort(int (*a)[5])
{
	int i=0,j=0,k=0;
	for(j=0;j<5;j++)
	{
		for(k=0;k<4;k++)
		{
			for(i=0;i<4-k;i++)
			{
				if(a[i][j]>a[i+1][j])
				{
					int tmp=a[i][j];
					a[i][j]=a[i+1][j];
					a[i+1][j]=tmp;
				}
			}
		}
	}
}
void print_A(int(*a)[5])
{
	int i=0,j=0;
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
}
int main()
{
	int i=0,j=0;
	int A[5][5];
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			scanf("%d",&A[i][j]);
		}
	}
	r_sort(A);
	c_sort(A);
	print_A(A);
	return 0;
}
