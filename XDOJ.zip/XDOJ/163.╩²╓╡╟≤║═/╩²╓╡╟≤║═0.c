#include<stdio.h>
int main()
{
	
	int N=0;
	int sum=0;
	int i=0,j=0;
	int arr[100][100];
	scanf("%d",&N);
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			scanf("%d",&arr[i][j]);
			if((i==j)||(i+j+1==N))
			{
				sum+=arr[i][j];
			}
		}
	}
	printf("%d",sum);
	return 0;
}
