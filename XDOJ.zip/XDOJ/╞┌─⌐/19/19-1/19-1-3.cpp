#include<stdio.h>
int main()
{
	int n=0;
	scanf("%d",&n);
	int i=0;
	int count=0;
	int arr[100];
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=0;i<n;i++)
	{
		while(arr[i]!=0)
		{
			if(arr[i]%10==1)
			{
				count++;
			}
			arr[i]/=10;			
		}
	}
	printf("%d",count);
	return 0;
}
