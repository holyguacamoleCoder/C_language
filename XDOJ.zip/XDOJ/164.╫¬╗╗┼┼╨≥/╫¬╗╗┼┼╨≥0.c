#include<stdio.h>
#include<ctype.h>
int main()
{
	char str[80];
	char s[80];
	gets(str);
	int i=0,j=0,k=0;
	while(str[i])
	{
		if(islower(str[i]))
		{
			str[i]=toupper(str[i]);
			s[k++]=toupper(str[i]);
		}
		else if(isupper(str[i]))
		{
			s[k++]=str[i];
		} 
		i++;
	}
	for(i=0;i<k-1;i++)
	{
		for(j=0;j<k-i-1;j++)
		{
			if(s[j]>s[j+1])
			{
				char tmp=s[j];
				s[j]=s[j+1];
				s[j+1]=tmp;
			}
		}
	}
	i=0;
	j=0;
	while(str[i])
	{
		if(isupper(str[i]))
		{
			str[i]=s[j++];
		}
		i++;
	}
	puts(str);
	return 0;
}
