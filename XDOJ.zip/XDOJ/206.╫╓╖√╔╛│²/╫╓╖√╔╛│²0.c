#include<stdio.h>
#include<string.h>
void dele(char str[],char ch)
{
	int i,j=0;
	for(i=0;i<(int)strlen(str);i++)
	{
		if(str[i]!=ch)
		{
			str[j++]=str[i];
		}
	}
	str[j]='\0';
	printf("%s",str);
}
int main()
{
	char str[50];
	char ch;
	gets(str);
	ch=getchar();
	dele(str,ch);
	return 0;
} 
