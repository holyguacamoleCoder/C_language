#include<stdio.h>
int GCF(int a,int b)
{
	int gcf=0;
	if(a>b)
	{
		gcf=b;
	}
	else
	{
		gcf=a;
	}
	while(!(a%gcf==0 && b%gcf==0))
	{
		gcf--;
	}
	return gcf;
}
int main()
{
	int n;
	int i=0;
	scanf("%d",&n);
	int arr[n];
	int gcf[n];
	int sum=0;
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=0;i<n-1;i++)
	{
		gcf[i]=GCF(arr[i],arr[i+1]);
		sum+=gcf[i];
	}
	printf("%d\n",sum);
	return 0;
}
