#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char *compress(char *src);
char *compress(char *src)
{
	char count[100],ch;
	int i=0,sum=0;
	while(*src)
	{
		for(i=0;i<sum-1;i++)
		{
			*count=ch;
		}
		sum=0;
		*count=*src;
		count++;
		ch=*src;
	}
	return count;
}
int main()
{
	char src[100];
	scanf("%s",src);

	char *ps = compress(src);
	
	puts(ps);
	return 0;
}
