#include <stdio.h>
int main(){
	int p=0;
	int i,j,sum = 0;
	int count = 0;
	
	scanf("%d",&p);
	
	for(i = 2;count <= p+10;i++)
	{
		int IsPrime = 1;
		
		for(j = 2;j < i;j++){
			if(i % j == 0){
				IsPrime = 0;
				break;
			}
		}
		
		if(IsPrime==1){
			count++;
			if(count>=p&&count<=p+10){
				sum+=i;
			}
		}
	}
	
	printf("%d",sum);
	
	return 0;
}
