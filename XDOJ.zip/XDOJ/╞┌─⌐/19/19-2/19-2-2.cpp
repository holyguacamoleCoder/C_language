#include<stdio.h>
int a_n(int n)
{
	return 3*(n-1)*(n-1)+2*(n-1)+1;
}
int main()
{
	int m=0;
	int i=0;
	int sum_even=0;
	int sum_odd=0;
	scanf("%d",&m);
	int count1=0;
	int count2=0;
	//n=7ʱa_nΪ119����100
	for(i=7;;i++)
	{
		int a=a_n(i);
		if(a%2==0)
		{
			if(count1!=m)
			{
				sum_even+=a;
				count1++;
			}
		}
		else
		{
			if(count2!=m-1)
			{
				sum_odd+=a;
				count2++;
			}
		}
		if(count1==m && count2==m-1)
		{
			break;
		}
	}
	printf("%d %d",sum_even,sum_odd);
	return 0;
}
