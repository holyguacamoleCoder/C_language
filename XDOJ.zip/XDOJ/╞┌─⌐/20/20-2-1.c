#include<stdio.h>
int main()
{
	int a=0;
	int arr[10]={0};
	//��������
	scanf("%d",&a);
	int i=0,j=0;
	for(i=0;i<10;i++)
	{
		scanf("%d",&arr[i]);
	}
	//ð������
	for(i=0;i<9;i++)
	{
		for(j=0;j<9-i;j++)
		{
			if(arr[j]>arr[j+1])
			{
				int tmp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=tmp;
			}
		}
	}
	//���ֲ��ң��ð���ѡ����2333��
	int new[10]={0};
	int flag=0;
	j=0;
	for(i=0;i<10;i++)
	{
		if(arr[i]==a)
		{
			flag=1;
			i++;
		}
		new[j++]=arr[i];
	}
	int n=10;
	if(flag==1)
		n=9;
	for(i=0;i<n;i++)
	{
		printf("%d ",new[i]);
	}
	return 0;
}
//10 9 8 7 6 5 4 3 2 1
