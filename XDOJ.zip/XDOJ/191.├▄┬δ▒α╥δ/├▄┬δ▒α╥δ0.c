#include<stdio.h>
int main()
{
	int i=0;
	char str[52];
	gets(str);
	while(str[i])
	{
		if(((str[i]<='Z')&&(str[i]>='A')))
		{
			str[i]=25-str[i]+2*'A';
		}
		else if(((str[i]<='z')&&(str[i]>='a')))
		{
			str[i]=25-str[i]+2*'a';
		}
		printf("%c",str[i]);
		i++;
	}
	return 0;
}
