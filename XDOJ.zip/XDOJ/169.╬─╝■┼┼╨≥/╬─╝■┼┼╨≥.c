#include<stdio.h>

int j_d(int y1,int m1,int d1,
		int y2,int m2,int d2)
{
	if(y1>y2)
	{
		return 1;
	}
	else if(y1==y2)
	{
		if(m1>m2)
		{
			return 1;
		}
		else if(m1==m2)
		{
			if(d1>d2)
			{
				return 1;
			}
			else if(d1<d2)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		}
		else 
		{
			return -1;
		}
	}
	else 
	{
		return -1;
	}
}

struct file
{
	int date[3];
	int width;
};


int main()
{
	int i=0,j=0;
	int n=0;
	scanf("%d",&n);
	struct file f[n];
	for(i=0;i<n;i++)
	{
		scanf("%d/%d/%d%d",&f[i].date[0],
						&f[i].date[1],
						&f[i].date[2],
						&f[i].width);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(j_d(f[j].date[0],f[j].date[1],f[j].date[2],
				f[j+1].date[0],f[j+1].date[1],f[j+1].date[2])<0)
			{
				struct file tmp=f[j];
				f[j]=f[j+1];
				f[j+1]=tmp;
			}
			else if(j_d(f[j].date[0],f[j].date[1],f[j].date[2],
				f[j+1].date[0],f[j+1].date[1],f[j+1].date[2])==0)
			{
				if(f[j].width<f[j+1].width)
				{
					struct file tmp=f[j];
					f[j]=f[j+1];
					f[j+1]=tmp;
				}
			}
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d/%d/%d %d\n",f[i].date[0],
								f[i].date[1],
								f[i].date[2],
								f[i].width);
	}
	return 0;
}
