#include<stdio.h>
int fun(char*str)
{
	int count=0;
	while(*str)
	{
		if((*str>=65&&*str<=90)||(*str>=97&&*str<=122))
		{
			count++;
		}
		str++;
	}
	return count;
}

int main()
{
	char arr[100];
	gets(arr);
	printf("%d",fun(arr));
	return 0;
}
