#include<stdio.h>
#include<math.h>
int main()
{
	int a=0;
	int b=0;
	scanf("%d %d",&a,&b);
	int i=0;
	int j=0;
	for(i=a;i<=b;i++)
	{
		int num=0;
		for(j=1;j<i;j++)
		{
			if(i%j==0)
			num+=j;
		}
		if(i==num)
		printf("%d\n",i);
	}
	return 0;
}
