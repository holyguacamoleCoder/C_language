#include<stdio.h>
void swap(int* a, int *b)
{
	int tmp =* a;
	*a = *b;
	*b = tmp;
}
int main()
{
	int n=0;
	int i=0;
	int j=0;
	int arr[30]={0};
	int count=1;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=0;i<n-1;i++)
	{
		for (j = 0; j < n - 1; j++)
		{
			if (arr[j] > arr[j + 1])
			{
				swap(&arr[j], &arr[j + 1]);
			}
		}
	}
	
	for (i = 0; i < n; i++)
	{
		if(arr[i]==arr[i+1])
		{
			count++;
		}
		else
		{
			printf("%d:%d\n", arr[i],count);
			count=1;
		}
	}
	return 0;
}
