#include<stdio.h>
#include<string.h>
int main()
{
	int len=0;
	int max=0;
	char arr[100];
	char str[100]; 
	while(1)
	{
		gets(arr);
		if(strcmp(arr,"***end***")==0)
		{
			break;
		}
		len=strlen(arr);
		if(max<len)
		{
			max=len;
			strcpy(str,arr);
		}
	}
	printf("%d\n%s",max,str);
	return 0;
}
