#include<stdio.h>
#include<math.h>
#define PI 3.1415926
int main()
{
	int r=0;
	int a =0;
	scanf("%d%d",&r,&a);
	double b=a*1.0*PI/180;
	if(r>=10000 || r<0)
	{
		printf("-1");
	}
	else if(r==0)
	{
		printf("Origin");
	}
	else if(r>0)
	{
		if(a%180==0)
		{
			printf("X-axis");
		}
		else if(a%90==0 && a%180!=0)
		{
			printf("Y-axis");
		}
		else if(sin(b)>0)
		{
			if(cos(b)>0)
			{
				printf("1st Quadrant");
			}
			else if(cos(b)<0)
			{
				printf("2nd Quadrant");
			}
		}
		else if(sin(b)<0)
		{
			if(cos(b)>0)
			{
				printf("3rd Quadrant");
			}
			else if(cos(b)<0)
			{
				printf("4th Quadrant");
			}
		}
	}
	return 0;
}
