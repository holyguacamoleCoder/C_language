//T1  ����
#include<stdio.h>
int main()
{
	int i=0;
	int n=0;
	scanf("%d",&n);
	int arr[n];
	int sum=0;
	double s_2=0;
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
		sum+=arr[i];
	}
	double averge=sum/n*1.0;
	for(i=0;i<n;i++)
	{
		s_2+=(arr[i]-averge)*(arr[i]-averge);
	}
	s_2/=n*1.0;
	printf("%lf",s_2);
	return 0;
}
