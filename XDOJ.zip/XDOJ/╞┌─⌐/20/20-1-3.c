#include<stdio.h>
int main()
{
	int A,B;
	int i=0;
	scanf("%d%d",&A,&B);
	if(B<=A)
	{
		int tmp=A;
		A=B;
		B=tmp;
	}
	int th=0,fo=0,fi_nt=0,min=0;
	for(i=A;i<=B;i++)
	{
		if(i%3==0)
			th++;
		if(i%4==0)
			fo++;
		if(i%5==0 && i%2!=0)
			fi_nt++;
	}
	if(th<fo)
		min=th;
	else
		min=fo;
	if(fi_nt<min)
		min=fi_nt;
	printf("%d %d %d\n%d",th,fo,fi_nt,min);
	return 0;
}
