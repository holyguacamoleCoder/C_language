#include<stdio.h>
int main()
{
	int i=0,k=0;
	int tmp=0;
	char ch[100];
	int  word[100];
	gets(ch);
	while(ch[i])
	{
		tmp++;
		if(ch[i]==' ' || ch[i]=='.')
		{
			word[k]=tmp-1;
			k++;
			tmp=0;
		}
		i++;
	}
	
	int max=0;
	for(i=0;i<k;i++)
	{
		if(word[max]<word[i])
		max=i;
	}
	printf("%d",word[max]);
	return 0;
}
