#include<stdio.h>
void sort_print(int*num,int n)
{
	int i=0,j=0;
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(*(num+j)>*(num+j+1))
			{
				int tmp=*(num+j);
				*(num+j)=*(num+j+1);
				*(num+j+1)=tmp;
			}
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d",*(num+i));
		if(i!=n-1)
		{
			printf(" ");
		}
	}
}

int main()
{
	int i=0;
	int j=0,k=0;
	int c1=0,c2=0;
	int num=0;
	int odd[20];
	int even[20];
	int N=0;
	scanf("%d",&N);
	for(i=0;i<N;i++)
	{
		scanf("%d",&num);
		if(num%2==1)
		{
			odd[c1++]=num;
		}
		else 
		{
			even[c2++]=num;
		}
	}
	sort_print(odd,c1);
	printf("   ");
	sort_print(even,c2);
	return 0;
}
