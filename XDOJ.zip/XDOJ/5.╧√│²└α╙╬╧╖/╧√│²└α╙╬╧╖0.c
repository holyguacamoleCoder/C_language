#include<stdio.h>
int main()
{
	int m,n;
	int i=0,j=0;
	int a[31][31], b[31][31];
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
			b[i][j]=a[i][j];
		}
	}
	//������
	for(i=0;i<n;i++)
	{
		for(j=0;j<m-2;j++)
		{
			if(a[i][j]==a[i][j+1]&&a[i][j]==a[i][j+2])
			{
				b[i][j]=0;
				b[i][j+1]=0;
				b[i][j+2]=0;
			}
		}
	}
	//������
	for(j=0;j<m;j++)	
	{
		for(i=0;i<n-2;i++)
		{
			if(a[i][j]==a[i+1][j]&&a[i][j]==a[i+2][j])
			{
				b[i][j]=0;
				b[i+1][j]=0;
				b[i+2][j]=0;
			}
		}
	}
	//���
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	return 0;
}
