#include<stdio.h>
int main()
{
	char C;
	char S[100];
	int n=0;
	int i=0;
	int count=0;
	scanf("%c %d",&C,&n);
	while(getchar()!='\n');
	gets(S);
	if(n==1)//����
	{
		while(S[i]!='\0')
		{
			if(S[i]==C)
			{
				count++;
			}
			i++;
		}
	}
	else if(n==0)//������
	{
		while(S[i]!='\0')
		{
			if(S[i]==C || (S[i]-32)==C || (S[i]+32)==C)
			{
				count++;
			}
			i++;
		}
	
	}
	printf("%d",count);
	return 0;
}
