#include<stdio.h>
#include<math.h>

int main()
{
	double x=0;
	scanf("%lf",&x);
	if(x>=0)
	{
		printf("%.2lf",sqrt(x));
	}
	else
	{
		printf("%.2lf",pow(x+1,2.0)+2*x+1.0/x);
	}
	return 0;
}
