#include <stdio.h>
int main()
{
	char a[14], code[12] = "0123456789X"; 
	gets(a); 
	int i, j = 1, sum = 0;
	for(i = 0; i < 12; i++) 
	{ 
    	if(a[i] == '-')   continue; 
     	sum += (a[i]-'0')*j++; 
 	}
	if(code[sum%11] == a[12])  
	{
		printf("Right");
	} 
	else
	{
      a[12] = code[sum%11];
      puts(a);
	}
	return 0;
}
