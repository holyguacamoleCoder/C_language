#include<stdio.h>
#include<string.h>
void wd_sort(char (*str)[20],int N)
{
	int i,j;
	char temp[20];
	for(i=0;i<(N-1);i++)
	{
		for(j=0;j<(N-i-1);j++)
		{
			if(strcmp(str[j],str[j+1])>0)
			{
				strcpy(temp,str[j]);
			    strcpy(str[j],str[j+1]);
				strcpy(str[j+1],temp);
			}
		}
	}
}
int main()
{
	int N,i;
	char str[10][20];
	scanf("%d",&N);
	for(i=0;i<N;i++)
	{
		scanf("%s",&str[i]);
	}
	wd_sort(str,N);
	for(i=0;i<N;i++)
	{
		printf("%s\n",str[i]);
	}
	return 0;
}
