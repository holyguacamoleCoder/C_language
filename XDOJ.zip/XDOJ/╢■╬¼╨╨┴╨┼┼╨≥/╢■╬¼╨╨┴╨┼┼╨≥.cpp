#include <stdio.h>

//���������ֱ��ÿһ�е�Ԫ�ؽ�������
void sort_d_array(int (*a)[4], int row, int col)
{
    int i,j,k,temp;

    for(i=0; i<row; i++)
    {
        for(k=0; k<col; k++)
        {
            for(j=0; j<col-k-1; j++)
            {
                if(a[i][j] > a[i][j+1])
                {
                    temp = a[i][j];
                    a[i][j] = a[i][j+1];
                    a[i][j+1] = temp;
                }
            }
        }
    }
}
//���������ֱ��ÿһ�е�Ԫ�ؽ�������
void sort_d_array_c(int (*a)[4], int row, int col)
{
    int i,j,k,temp;

    for(i=0; i<col; i++)
    {
        for(k=0; k<row; k++)
        {
            for(j=0; j<row-k-1; j++)
            {
                if(a[j][i] > a[j+1][i])
                {
                    temp = a[j][i];
                    a[j][i] = a[j+1][i];
                    a[j+1][i] = temp;
                }
            }  
        }
    }
}

//��ӡ���
void print_d_array(int (*a)[4], int row, int col)
{
	int  i;
	int j;
	for(i=0; i<row; i++)
	{
		for(j=0; j<col; j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
}



int main(int argc, const char * argv[])
{
	int a[4][4] = {
		1,	80,	30,	 50,
		20, 50, 29,  9,
		10, 40, 30, 20,
		5, 	90,	80, 100,
	};

	int i,j;
	int max;
	int min;
	int temp;
	sort_d_array(a, 4, 4);
	sort_d_array_c(a, 4, 4);
	print_d_array(a, 4, 4);

	
//	for (i = 0; i < 4; i++) 
//	{
//		max = 0;
//		for (j = 0; j < 4; j++) {
//			if (a[i][j] > a[i][max])
//				max = j;
//		}
//		
//		min = 0;
//		for (j = 0; j < 4; j++) {
//			if (a[j][max] < a[min][max])
//				min = j;
//		}
//
//		if (min == i)
//			printf("%d\n", a[min][max]);
//	}

	return 0;
}

