#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	double delt=pow(b*b-4*a*c,0.5);
	if(delt>0)
	{
		double x1=(b*(-1)+delt)/(2.0*a);
		double x2=(b*(-1)-delt)/(2.0*a);
		printf("%.lf",x1*x1+x2*x2);
	}
	else if(delt==0)
	{
		printf("%.lf",b*(-1)/(2.0*a));
	}
	else
	{
		printf("No real roots");
	}
	return 0;
}
