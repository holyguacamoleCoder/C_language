//#include<stdio.h>
//#include<string.h>
//int main()
//{
//	int i=1;
//	int j=0;
//	int k=0;
//	char str[100];
//	char less[100];
//	char more[200];
//	gets(str);
//	char first[2];
//	first[0]=str[0];
//	//first[1]='\0';
//	while(str[i]!='\0')//�����ַ���
//	{
//		if(str[i]>str[0])//��-��
//		{
//			more[k]=str[i];
//			k++;
//		}
//		else//С-��
//		{
//			less[j]=str[i];
//			j++;
//		}
//		i++;
//	}
//	//more[k] = '\0' ;
//	//less[j] = '\0' ;
//	int n=j;
//	for(j=0;j<n-1;j++)//С������
//	{
//		for(i=0;i<n-1;i++)
//		{
//			if(less[i]>less[i+1])
//			{
//				char tmp=less[i];
//				less[i]=less[i+1];
//				less[i+1]=tmp;
//			}
//		}
//	}
//	strcat(more,first);
//	strcat(more,less);
//	printf("%s",more);
//	return 0;
//}
